// should not crash
return 0;
