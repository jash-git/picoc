#include <stdio.h>

char a;
short b;

printf("%d %d\n", sizeof(char), sizeof(a));
printf("%d %d\n", sizeof(short), sizeof(b));

void main() {}
