This is picoc (http://code.google.com/p/picoc/) port for Win32.

The port has been compiled from state r572 using MS VS 2005 SP1.

The following fixes have been made:

- PATH_MAX defined as 255.

- In unistd.c, disabled functions not supported by MS VC.

- In string.c, enabled strdup, index and rindex functions.

- Added version number display.

- Changed quick help format.

- Version number changed to 2.2.m.

The package contains four executables for static/DLL CRT and for x86/x64.

All tests supplied with picoc sources have been passed except of
"42_function_pointer.c" (maybe there is a bug in the interpreter).

The port has been made by Eugene V. Muzychenko, Novosibirsk, Russia.
